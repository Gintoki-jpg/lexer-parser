#include"main.h"
using namespace std;

Lexer::Lexer(string fileName) : fileName(fileName), countChar(0), countLine(1), countColumn(1) //ð�ų�ʼ������ʽ
{
    fileSource.open(fileName);
    assert(fileSource.is_open());
    #define TOKEN_TYPE(TYP) count_##TYP = 0;
    #include "def/TOKEN_TYPE.def"
    #undef TOKEN_TYPE
    stringBuffer.clear();
}

Lexer::Lexer()
{
}

Lexer::~Lexer()
{
}

char Lexer::getChar(){
    char ch = fileSource.get();
    if (ch >= 0)
        stringBuffer.push_back(ch);
    else
    {
        return 0;
    }
    if (ch == '\n')
    {
        countLine++;
        countColumn = 1;
    }
    else
    {
        countColumn++;
    }
    countChar++;
    return ch;
}

char Lexer::peekChar(){
    return fileSource.peek();
}

void Lexer::printResult()
{
    cout << endl;
    cout<<"<=====Blow is a summary=====> "<<endl;
    cout << "Total characters:\t" << countChar << endl;
    cout << "Total lines:\t\t" << countLine << endl;
    #define TOKEN_TYPE(TYP) cout <<"Total "<< #TYP << ":\t" << count_##TYP << endl;
    #include "def/TOKEN_TYPE.def"
    #undef TOKEN_TYPE
}

void Lexer::getIdentifierKeyword(Token &token)
{
    token.setType("Identifier");
    getChar();
    while(1)
    {
        char ch = peekChar();
        if (isAlpha(ch))
        {
            getChar();
        }
        else
            break;
    }
    #define KEYWORD(TOK)     \
        if (stringBuffer == #TOK) \
            token.setType("Keyword"), count_Keyword++;
    #include "def/KEYWORD.def"
    #undef KEYWORD
    if (token.getType() == "Identifier")
    {
        count_Identifier++;
    }
    token.setToken(stringBuffer);
}

void Lexer::getNumericalConstant(Token &token)
{
    token.setType("Numerical_Constant");
    getChar();
    unsigned state = 1;
    char ch;
    while(state!=0){
        switch (state)
        {
        case 0:
            break;
        case 1:
            ch = peekChar();
            if (isdigit(ch))
            {
                state = 1;
                getChar();
            }
            else if (ch == '.')
            {
                state = 2;
                getChar();
            }
            else if (ise(ch))
            {
                state = 4;
                getChar();
            }
            else if (isAlpha(ch))
            {
                token.setType("Error");
                token.setError("illegal name");
                count_Error++;
                state = 7;
                getChar();
            }
            else
            {
                state = 0;
            }
            break;
        case 2:
            ch = peekChar();
            if (isdigit(ch))
            {
                state = 3;
                getChar();
            }
            else
            {
                state = 0;
            }
            break;
        case 3:
            ch = peekChar();
            if (isdigit(ch))
            {
                state = 3;
                getChar();
            }
            else if (ise(ch))
            {
                state = 4;
                getChar();
            }
            else
            {
                state = 0;
            }
            break;
        case 4:
            ch = peekChar();
            if (isdigit(ch))
            {
                state = 6;
                getChar();
            }
            else if (ch == '+' || ch == '-')
            {
                state = 5;
                getChar();
            }
            else
            {
                state = 0;
            }
            break;
        case 5:
            ch = peekChar();
            if (isdigit(ch))
            {
                state = 6;
                getChar();
            }
            else
            {
                state = 0;
            }
            break;
        case 6:
            ch = peekChar();
            if (isdigit(ch))
            {
                state = 6;
                getChar();
            }
            else
            {
                state = 0;
            }
            break;
        case 7:
            ch = peekChar();
            if (isAlpha(ch))
            {
                state = 7;
                getChar();
            }
            else
            {
                state = 0;
            }
        default:
            break;
        }
    }
    token.setToken(stringBuffer);
    if (token.getType() == "Numerical_Constant")
    {
        count_Numerical_Constant++;
    }
}

void Lexer::getCharConstant(Token &token)
{
    token.setType("Char_Constant");
    getChar();
    unsigned state = 1;
    char ch;
    while(state!=0)
    {
        switch (state)
        {
        case 1:
            ch = peekChar();
            if (ch == '\\')
            {
                state = 3;
                getChar();
            }
            else if (ch == '\'')
            {
                state = 0;
                getChar();
            }
            else
            {
                state = 2;
                getChar();
            }
            break;
        case 2:
            ch = peekChar();
            if (ch == '\'')
            {
                state = 0;
                getChar();
            }
            else
            {
                state = 0;
            }
            break;
        case 3:
            state = 2;
            getChar();
            break;
        default:
            break;
        }
    }
    token.setToken(stringBuffer);
    if (token.getType() == "Char_Constant")
    {
        count_Char_Constant++;
    }
}

void Lexer::getStringConstant(Token &token)
{
    token.setType("String_Literal");
    getChar();
    unsigned state = 1;
    char ch;
    while(state!=0)
    {
        switch (state)
        {
        case 1:
            ch = peekChar();
            if (ch == '\\')
            {
                state = 2;
                getChar();
            }
            else if (ch == '\"')
            {
                state = 0;
                getChar();
            }
            else if (ch == '\n')
            {
                token.setType("Error");
                token.setError("unclosed string");
                count_Error++;
                state = 0;
            }
            else
            {
                state = 1;
                getChar();
            }
            break;
        case 2:
            state = 1;
            getChar();
            break;
        default:
            break;
        }
    }
    token.setToken(stringBuffer);
    if (token.getType() == "String_Literal")
    {
        count_String_Literal++;
    }
}

void Lexer::getPunctuator(Token &token,char &ch,bool &res)
{
    getChar();
    bool has_error = false;
    bool is_comment = false;
    switch (ch)
    {
        case '.':
            ch = peekChar();
            if (ch == '.')
            {
                getChar();
                if ((ch = peekChar()) == '.')
                {
                    getChar();
                }
                else
                {
                    has_error = true;
                    token.setType("Error");
                }
            }
            break;
        case '>':
            ch = peekChar();
            if (ch == '>')
            {
                getChar();
                ch = peekChar();
                if (ch == '=')
                {
                    getChar();
                }
            }
            else if (ch == '=')
                getChar();
            break;
        case '<':
            ch = peekChar();
            if (ch == '<')
            {
                getChar();
                if ((ch = peekChar()) == '=')
                {
                    getChar();
                }
            }
            else if (ch == '=')
                getChar();
            break;
        case '+':
            ch = peekChar();
            if (ch == '=' || ch == '+')
                getChar();
            break;
        case '-':
            ch = peekChar();
            if (ch == '=' || ch == '-' || ch == '>')
                getChar();
            break;
        case '&':
            ch = peekChar();
            if (ch == '=' || ch == '&')
                getChar();
            break;
        case '|':
            ch = peekChar();
            if (ch == '=' || ch == '|')
                getChar();
            break;
        case '*':
        case '%':
        case '^':
        case '=':
        case '!':
            ch = peekChar();
            if (ch == '=')
                getChar();
            break;
        case ';':
        case '{':
        case '}':
        case ',':
        case ':':
        case '(':
        case ')':
        case '[':
        case ']':
        case '~':
        case '?':
            break;
        case '#':                       //C�����е�ע��Ӧ�ò���#�ɣ�Ӧ����//��/**/��ע�⣬��ȷ������������#�궨��Ķ�������Ҳ��Ϊ��ע�Ͳ����дʷ�����
            is_comment = true;
            do
            {
                ch = getChar();
            } while (ch != '\n');
            break;
        case '/':
            ch = peekChar();
            if (ch == '*' || ch == '/')//C�����У�ֻҪ��/*����//����ע�͵Ŀ�ʼ
            {
                is_comment = true;
                unsigned state = 1;
                do
                {
                    ch = peekChar();
                    if (ch <= 0)
                        state = 5;
                    switch (state)
                    {
                    case 1:
                        if (ch == '*')
                        {
                            state = 2;
                            getChar();
                        }
                        else if (ch == '/')
                        {
                            state = 4;
                            getChar();
                        }
                        break;
                    case 2:
                        if (ch == '*')
                        {
                            state = 3;
                            getChar();
                        }
                        else
                        {
                            state = 2;
                            getChar();
                        }
                        break;
                    case 3:
                        if (ch == '*')
                        {
                            state = 3;
                            getChar();
                        }
                        else if (ch == '/')
                        {
                            state = 0;
                            getChar();
                        }
                        else
                        {
                            state = 2;
                            getChar();
                        }
                        break;
                    case 4:
                        if (ch == '\n')
                        {
                            state = 0;
                            getChar();
                        }
                        else
                        {
                            state = 4;
                            getChar();
                        }
                        break;
                    default:
                        state = 0;
                        token.setType("Error");
                        token.setError("unterminated comment");
                        count_Error++;
                        break;
                    }
                } while (state != 0);
            }
            else if (ch == '=')
                getChar();
            break;
        default:
            token.setType("Error");
            token.setError("unexpected character");
            count_Error++;
            token.setToken(stringBuffer);                //�����Ǵ����ҲҪ���棬�����Ƿ����������һ�ִ�������ʽ
            break;
        }
    res &= !has_error;
    if (!is_comment)
    {
        if (token.getType() == "Punctuator")
        {
            count_Punctuator++;
        }
        token.setToken(stringBuffer);
        cout << token << endl;
    }
    else if (has_error)
    {
        cout << token << endl;
    }
}

bool Lexer::lexer()
{
    bool res = 1;
    while (!(fileSource.eof() && stringBuffer.empty()))
    {
        char ch = peekChar();
        if (isAlpha(ch))
        {
            Token token("Identifier", countLine, countColumn, "");
            getIdentifierKeyword(token);
            cout << token << endl;
        }
        else if (isdigit(ch))
        {
            Token token("Numerical_Constant", countLine, countColumn, "");
            getNumericalConstant(token);
            cout << token << endl;
        }
        else if (ch == '\'')
        {
            Token token("Char_Constant", countLine, countColumn, "");
            getCharConstant(token);
            cout << token << endl;
        }
        else if (ch == '\"')
        {
            Token token("String_Literal", countLine, countColumn, "");
            getStringConstant(token);
            cout << token << endl;
        }
        else
        {
            if (!isws(ch))
            {
                Token token("Punctuator", countLine, countColumn, "");
                getPunctuator(token,ch,res);
            }
            else
            {
                getChar();
            }
        }
        stringBuffer.clear();
    }
    return res;
}














