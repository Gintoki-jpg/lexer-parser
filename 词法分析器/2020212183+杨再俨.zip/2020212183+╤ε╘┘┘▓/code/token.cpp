#include "main.h"
using namespace std;


Token::Token(string tokentype, unsigned line, unsigned column, string token) : tokenType(tokentype), tokenLine(line), tokenColumn(column), tokenString(token)
{
}

Token::Token()
{
}

Token::~Token()
{
}

string Token::getType() const
{
    return tokenType;
}

void Token::setType(string tokentype)
{
    this->tokenType = tokentype;
}

void Token::setToken(string token)
{
    this->tokenString = token;
}

void Token::setError(string error)
{
    this->tokenError = error;
}

ostream &operator<<(ostream &os, const Token &token)
{
    if (token.tokenType != "Error")
    {
        os << "Type: "<<token.tokenType<<endl<<
        "Location: "<<token.tokenLine << ':' << token.tokenColumn << endl <<
        "Value: "<< token.tokenString << endl;
    }
    else
    {
        /*
        os << "\033[1m" << token.line_ << ":" << token.column_ << ": "
           << "\033[31mError: \033[32m" << token.error_ << "\033[39m " << token.token_ << "\033[0m";
        */
        os <<"\033[31mError: \033[32m" << token.tokenError <<endl<<
        "\033[1m"<<"Loacation: " << token.tokenLine << ":" << token.tokenColumn <<endl<<
        "\033[39m"<<"Value: " << token.tokenString << "\033[0m"<<endl;
    }
    return os;
}


