#include"main.h"
using namespace std;

void SyntaxAnalyzer::global_init(PREDICT_TABLE M,PRODUCTION P){
    //1.��ȡLR(1)������������PREDICT_TABLE
    PREDICT_TABLE table;
    ifstream file("lr1.csv");
    if (!file.is_open())
    {
        cout << "Error: File not found!" << endl;
        return;
    }
    string line;
    vector<string> tokens;
    getline(file, line);
    string word;
    //�����ս��(����)
    for (int i = 0; i < line.size(); i++)
    {
        if (line[i] == ',' || line[i] == '\n')
        {
            if (word.size() > 0 && word.compare("state") != 0)
            {
                tokens.push_back(word);
                cout<<word<<endl;
                word.clear();
            }
            else
            {
                word.clear();
            }
        }
        else
        {
            word += line[i];
        }
    }
    //����state(����)
    while (getline(file, line))
    {
        string word;
        int count = 0;
        string state;
        for (int i = 0; i < line.size(); i++)
        {
            if (line[i] == ',')
            {
                if (count == 0)
                {
                    table.insert(make_pair(word, map<string, string>()));
                    state = word;
                    //cout<<word<<endl;
                    count++;
                }
                else if (word != string("0"))
                {
                    table[state].insert(make_pair(tokens[count - 1], word));
                    //cout<<word<<endl;
                    count++;
                }
                else
                {
                    count++;
                }
                word.clear();
            }
            else
            {
                word += line[i];
                //cout<<word<<endl;
            }
        }
    }
    file.close();
    M=table;
    cout<<"PREDICT_TABLE ��ʼ�����..."<<endl;
    //2.�������ʽ��ʼ��PRODUCTION
    vector<pair<string, string>> formula;
    formula.push_back(make_pair("E","E+T"));
    formula.push_back(make_pair("E","E-T"));
    formula.push_back(make_pair("E","T"));
    formula.push_back(make_pair("T","T*F"));
    formula.push_back(make_pair("T","T/F"));
    formula.push_back(make_pair("T","F"));
    formula.push_back(make_pair("F","(E)"));
    formula.push_back(make_pair("F","num"));
    cout<<"PRODUCTION ��ʼ�����..."<<endl;
    P=formula;
//    ifstream file_1("lr1.conf");
//    if (!file_1.is_open())
//    {
//        cout << "Error: file_1  not found" << endl;
//        return;
//    }
//    vector<pair<string, string>> formula;
//    while (getline(file_1, line))
//    {
//        string word[2];
//        int count = 0;
//        for (int i = 0; i < line.size(); i++)
//        {
//            if (line[i] == '-' && i + 1 < line.size() && line[i + 1] == '>')
//            {
//                count++;
//                i++;
//            }
//            else
//            {
//                word[count] += line[i];
//            }
//        }
//        formula.push_back(make_pair(word[0], word[1]));
//    }
//    P = formula;

}

void SyntaxAnalyzer::create_analyze_table(string str,PREDICT_TABLE M,PRODUCTION P)
{
    cout<<"\t\t\t\t\t\t<=======================Analyze Table======================>"<<endl;
    cout<<"State stack\t\t\t\tSymbol stack\t\t\t\tRemaining string\t\tAction"<<endl;;
    int ip = 0;
    vector<string> state_stack;
    vector<string> stack;
    state_stack.push_back("I0");
    str.push_back('$');
    while (true)
    {
        int ipAdd = 0;
        string state = state_stack.back();
        string a;
        if (start_pattern(str.substr(ip), "num"))
        {
            a = "num";
            ipAdd = 3;
        }
        else
        {
            a = str[ip];
            ipAdd = 1;
        }
        //�������ͣ�״̬Ii��δ�ҵ�
        if (M.find(state) == M.end())
        {
            cout << "Error: state " << state << " is not found" << endl;
            return;
        }
        //�������ͣ�ĳ״̬��Ӧ��token�쳣(δ�ҵ�)
        if (M[state].find(a) == M[state].end())
        {
            cout << "Error: Unexpected token " << a << " in state " << state << endl;
            ip += ipAdd;
            continue;
            return;
        }
        string next_state = M[state][a];
        if (start_pattern(next_state, "s") || start_pattern(next_state, "S"))
        {
            print_analyze_table(stack, state_stack, str.substr(ip), "Shift " + next_state);
            stack.push_back(a);
            state_stack.push_back("I" + next_state.substr(1));
            ip += ipAdd;
        }
        else if (start_pattern(next_state, "r"))
        {
            int counti = 0;
            int r = stoi(next_state.substr(1));
            print_analyze_table(stack, state_stack, str.substr(ip), "Reduce " + P[r - 1].first + " -> " + P[r - 1].second);
            for (int i = 0; i < P[r - 1].second.size(); i++)
            {
                if (P[r - 1].second[i] == 'm' && i > 1 && P[r - 1].second[i - 1] == 'u' && P[r - 1].second[i - 2] == 'n')
                {
                    counti -= 2;
                }
                counti++;
            }
            for (int i = 0; i < counti; i++)
            {
                stack.pop_back();
                state_stack.pop_back();
            }
            stack.push_back(P[r - 1].first);
            state_stack.push_back("I" + M[state_stack.back()][P[r - 1].first]);
        }
        else if (next_state == string("acc"))
        {
            print_analyze_table(stack, state_stack, str.substr(ip), "Accept");
            return;
        }
        //�������ͣ���������û�ж�Ӧ����Ϊ
        else
        {
            cout << "Error: Undefined behavior " << next_state << endl;
            return;
        }
    }
}

void SyntaxAnalyzer::print_analyze_table(vector<string> stack, vector<string> state_stack, string str, string action)
    {
        string ans;
        for (auto i : state_stack)
        {
            ans += i + " ";
        }
        cout << ans;
        for (int i = 0; i < (5 - ans.size() / 8); i++)
        {
            cout << "\t";
        }
        int count_=0;
        for (auto i : stack)
        {
            cout << i << " ";
            count_=count_+1;
        }
        for (int i = 0; i < (5 - count_ / 8); i++)
        {
            cout << "\t";
        }
        cout << str;
        for (int i = 0; i < (4 - str.size() / 8); i++)
        {
            cout << "\t";
        }
        cout << action ;
        cout << endl;
    };

int SyntaxAnalyzer::start_pattern(string str, string pattern)
{
    return str.find(pattern) == 0 ? 1 : 0;
}

string SyntaxAnalyzer::id_translate(string input_string)
{
    string newStr;
    int isId = 0;
    for (int i = 0; i < input_string.size(); i++)
    {
        if ((input_string[i] >= '0' && input_string[i] <= '9') || input_string[i] == '.')
        {
            if (!isId)
            {
                isId = 1;
                newStr += "num";
            }
            continue;
        }
        else
        {
            isId = 0;
            newStr += input_string[i];
        }
    }
    return newStr;
}


