#include"main.h"
using namespace std;
PREDICT_TABLE M;
PRODUCTION P;

void PREDICT_TABLE_init(string file_name)
{
    ifstream file(file_name);
    if (!file.is_open())
    {
        cout << "Error: file " << file_name << " not found" << endl;
        return;
    }
    PREDICT_TABLE table;
    string line;
    vector<string> tokens;
    getline(file, line);
    string word;
    for (int i = 0; i < line.size(); i++)
    {
        if (line[i] == ',' || line[i] == '\n')
        {
            string str2 = "state";
            if (word.size() > 0 && word.compare(str2) != 0)
            {
                tokens.push_back(word);
                //cout<<word<<endl;
                word.clear();
            }
            else
            {
                word.clear();
            }
        }
        else
        {
            word += line[i];
        }
    }
    while (getline(file, line))
    {
        string word;
        int count = 0;
        string state;
        for (int i = 0; i < line.size(); i++)
        {
            if (line[i] == ',')
            {
                if (count == 0)
                {
                    table.insert(make_pair(word, map<string, string>()));
                    state = word;
                    count++;
                }
                else if (word != string("0"))
                {
                    table[state].insert(make_pair(tokens[count - 1], word));
                    count++;
                }
                else
                {
                    count++;
                }
                word.clear();
            }
            else
            {
                word += line[i];
            }
        }
    }
    file.close();
    M = table;
    cout<<"PREDICT_TABLE_init success..."<<endl;
}

//void PRODUCTION_init(string file_name)
//{
//    ifstream file(file_name);
//    if (!file.is_open())
//    {
//        cout << "Error: File " << file_name << " not found" << endl;
//        return;
//    }
//    vector<pair<string, string>> formula;
//    string line;
//    while (getline(file, line))
//    {
//        string word[2];
//        int count = 0;
//        for (int i = 0; i < line.size(); i++)
//        {
//            if (line[i] == '-' && i + 1 < line.size() && line[i + 1] == '>')
//            {
//                count++;
//                i++;
//            }
//            else
//            {
//                word[count] += line[i];
//            }
//        }
//        formula.push_back(make_pair(word[0], word[1]));
//    }
//    P = formula;
//}

void PRODUCTION_init()
{
    vector<pair<string, string>> formula;
    formula.push_back(make_pair("E","E+T"));
    formula.push_back(make_pair("E","E-T"));
    formula.push_back(make_pair("E","T"));
    formula.push_back(make_pair("T","T*F"));
    formula.push_back(make_pair("T","T/F"));
    formula.push_back(make_pair("T","F"));
    formula.push_back(make_pair("F","(E)"));
    formula.push_back(make_pair("F","num"));
    P = formula;
    cout<<"PRODUCTION_init success..."<<endl;
}



int main()
{
    SyntaxAnalyzer SA;
    //SA.global_init(M,P);
    //PRODUCTION_init("lr1.conf");
    PRODUCTION_init();
    PREDICT_TABLE_init("lr1.csv");
    cout << "Please enter the string to be analyzed��" << endl;
    string input_str;
    cin >> input_str;
    input_str = SA.id_translate(input_str);
    cout<<"Num_translate_success,the new string is��"<<input_str<<endl;
    SA.create_analyze_table(input_str,M,P);
    system("pause");
    return 0;
}
