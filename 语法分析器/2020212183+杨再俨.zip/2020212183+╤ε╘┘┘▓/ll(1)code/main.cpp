#include"main.h"
using namespace std;

int main()
{
    Syntax_Analyzer SA;
    GRAMMAR_TABLE G;
    FIRST_TABLE first_table;
    FOLLOW_TABLE follow_table;
    SA.global_init(G, first_table, follow_table);
    PREDICT_TABLE M = SA.create_predict_table(G, first_table, follow_table);
    SA.print_predict_table(M);

    cout << "Please enter the string to be analyzed:" << endl;
    string input_string;
    cin >> input_string;
    input_string = SA.id_translate(input_string);
    ANALYZE_TABLE AT = SA.create_analyze_table(input_string, M);
    SA.print_analyze_table(AT);

    system("pause");
    return 0;
}
