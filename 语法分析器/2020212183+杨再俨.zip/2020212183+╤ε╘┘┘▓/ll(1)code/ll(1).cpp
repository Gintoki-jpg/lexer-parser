#include "main.h"
using namespace std;

void Syntax_Analyzer::global_init(GRAMMAR_TABLE &G, FIRST_TABLE &first_table, FOLLOW_TABLE &follow_table)
{
    //1.初始化每个非终结符能够产生的所有推导结果集合（即产生式集合）
    //这里由于使用E'这种形式会变成双字符不利于后续处理，所以我们将E'变为了G，将T'变成了U
    vector<string> E_vector;
    E_vector.push_back("TG");
    G.production.insert(pair<string, vector<string>>("E", E_vector));

    vector<string> G_vector;
    G_vector.push_back("+TG");
    G_vector.push_back("-TG");
    G_vector.push_back("ε");
    G.production.insert(pair<string, vector<string>>("G", G_vector));

    vector<string> T_vector;
    T_vector.push_back("FU");
    G.production.insert(pair<string, vector<string>>("T", T_vector));

    vector<string> U_vector;
    U_vector.push_back("*FU");
    U_vector.push_back("/FU");
    U_vector.push_back("ε");
    G.production.insert(pair<string, vector<string>>("U", U_vector));

    vector<string> F_vector;
    F_vector.push_back("(E)");
    F_vector.push_back("id");
    G.production.insert(pair<string, vector<string>>("F", F_vector));
    //2.初始化所有终结符和非终结符
    G.nonterminal.push_back("E");
    G.nonterminal.push_back("G");
    G.nonterminal.push_back("T");
    G.nonterminal.push_back("U");
    G.nonterminal.push_back("F");
    G.terminator.push_back("+");
    G.terminator.push_back("-");
    G.terminator.push_back("*");
    G.terminator.push_back("/");
    G.terminator.push_back("(");
    G.terminator.push_back(")");
    G.terminator.push_back("id");
    G.terminator.push_back("$");
    G.start_symbol = "E";
    //3.初始化每个非终结符对应的First集合与Follow集合
    vector<string> E_first_vector;
    E_first_vector.push_back("(");
    E_first_vector.push_back("id");
    first_table.insert(pair<string, vector<string>>("E", E_first_vector));

    vector<string> G_first_vector;
    G_first_vector.push_back("+");
    G_first_vector.push_back("-");
    G_first_vector.push_back("ε");
    first_table.insert(pair<string, vector<string>>("G", G_first_vector));

    vector<string> T_first_vector;
    T_first_vector.push_back("(");
    T_first_vector.push_back("id");
    first_table.insert(pair<string, vector<string>>("T", T_first_vector));

    vector<string> U_first_vector;
    U_first_vector.push_back("*");
    U_first_vector.push_back("/");
    U_first_vector.push_back("ε");
    first_table.insert(pair<string, vector<string>>("U", U_first_vector));

    vector<string> F_first_vector;
    F_first_vector.push_back("(");
    F_first_vector.push_back("id");
    first_table.insert(pair<string, vector<string>>("F", F_first_vector));

    vector<string> E_follow_vector;
    E_follow_vector.push_back("$");
    E_follow_vector.push_back(")");
    follow_table.insert(pair<string, vector<string>>("E", E_follow_vector));

    vector<string> G_follow_vector;
    G_follow_vector.push_back("$");
    G_follow_vector.push_back(")");
    follow_table.insert(pair<string, vector<string>>("G", G_follow_vector));

    vector<string> T_follow_vector;
    T_follow_vector.push_back("+");
    T_follow_vector.push_back("-");
    T_follow_vector.push_back("$");
    T_follow_vector.push_back(")");
    follow_table.insert(pair<string, vector<string>>("T", T_follow_vector));

    vector<string> U_follow_vector;
    U_follow_vector.push_back("+");
    U_follow_vector.push_back("-");
    U_follow_vector.push_back("$");
    U_follow_vector.push_back(")");
    follow_table.insert(pair<string, vector<string>>("U", U_follow_vector));

    vector<string> F_follow_vector;
    F_follow_vector.push_back("*");
    F_follow_vector.push_back("/");
    F_follow_vector.push_back("+");
    F_follow_vector.push_back("-");
    F_follow_vector.push_back("$");
    F_follow_vector.push_back(")");
    follow_table.insert(pair<string, vector<string>>("F", F_follow_vector));
}


PREDICT_TABLE Syntax_Analyzer::create_predict_table(GRAMMAR_TABLE G, FIRST_TABLE first_table, FOLLOW_TABLE follow_table)
{
    PREDICT_TABLE M;
    //加入所有非终结符
    M.table.insert(pair<string, map<string, string>>("E", map<string, string>()));
    M.table.insert(pair<string, map<string, string>>("G", map<string, string>()));
    M.table.insert(pair<string, map<string, string>>("T", map<string, string>()));
    M.table.insert(pair<string, map<string, string>>("U", map<string, string>()));
    M.table.insert(pair<string, map<string, string>>("F", map<string, string>()));
    //遍历G的production，根据first集合和follow集合填空
    for (auto iter = G.production.begin(); iter != G.production.end(); iter++)
    {
        string A = iter->first;//iter指向的对象production是一个<string, vector<string>>，分别使用first和second迭代遍历string和vector对象
        for (auto iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++)
        {
            string alpha = *iter2;
            if (alpha[0] >= 'A' && alpha[0] <= 'Z') //如果vector中的元素的第一个字符是大写字母如"FU"
            {
                vector<string> first_vector = first_table.find(string(1, alpha[0]))->second;    //根据first集合构造预测分析表
                for (auto a = first_vector.begin(); a != first_vector.end(); a++)
                {
                    if (*a != "ε")
                    {
                        M.table.find(A)->second.insert(pair<string, string>(*a, alpha));
                    }
                }
                if (find(first_vector.begin(), first_vector.end(), "ε") != first_vector.end()) //假如ε属于first(产生式右部符号)
                {
                    vector<string> follow_vector = follow_table.find(A)->second;
                    for (auto b = follow_vector.begin(); b != follow_vector.end(); b++)
                    {
                        if (*b != "ε")
                        {
                            M.table.find(A)->second.insert(pair<string, string>(*b, alpha));
                        }
                    }
                }
            }
            else
            {
                string alpha_first;
                if (start_pattern(alpha, "id"))        //如果产生式右部以id开头则将first赋值为id(之所以不与else合并是因为id是两个字符，不符合alpha[0]的要求)
                {
                    alpha_first = "id";
                }
                else if (start_pattern(alpha, "ε"))
                {
                    alpha_first = "ε";
                }
                else
                {
                    alpha_first = alpha[0];
                }

                if (alpha_first != "ε")
                {
                    M.table.find(A)->second.insert(pair<string, string>(alpha_first, alpha));
                }
                if (alpha_first == "ε")
                {
                    vector<string> follow_vector = follow_table.find(A)->second;
                    for (auto b = follow_vector.begin(); b != follow_vector.end(); b++)
                    {
                        if (*b != "ε")
                        {
                            M.table.find(A)->second.insert(pair<string, string>(*b, alpha));
                        }
                    }
                }
            }
        }
    }
    //遍历G的非终结符，将上一步填充的对应产生式insert到M的table中，若没有对应的产生式则填入"error"
    for (auto iter = G.nonterminal.begin(); iter != G.nonterminal.end(); iter++)
    {
        string A = *iter;
        for (auto iter2 = G.terminator.begin(); iter2 != G.terminator.end(); iter2++)
        {
            string a = *iter2;
            if (M.table.find(A)->second.find(a) == M.table.find(A)->second.end())
            {
                M.table.find(A)->second.insert(pair<string, string>(a, "error"));
            }
        }
    }
    M.nonterminal = G.nonterminal;
    M.terminator = G.terminator;
    M.start_symbol = G.start_symbol;
    cout<<"Predict table build successfully!"<<endl;
    return M;
}

void Syntax_Analyzer::print_predict_table(PREDICT_TABLE M)
    {
        cout << "\t\t\t\t<====================Predict table====================>" << endl;
        cout << "\t";
        for (auto iter : M.table.begin()->second)
        {
            cout << iter.first << "\t\t";
        }
        cout << endl;
        for (auto iter = M.table.begin(); iter != M.table.end(); iter++)
        {
            cout << iter->first << "\t";
            for (auto iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++)
            {
                string output_str;
                if (iter2->second == "error")
                {
                    output_str = "error";
                }
                else if (iter2->second == "ε")
                {
                    output_str = iter->first + "-><epsilon>";
                }
                else
                {
                    output_str = iter->first + "->" + iter2->second;
                }
                if (output_str.length() >= 8)
                {
                    cout << output_str << "\t";
                }
                else
                {
                    cout << output_str << "\t\t";
                }
            }
            cout << endl;
        }
    }

ANALYZE_TABLE Syntax_Analyzer::create_analyze_table(string input_string, PREDICT_TABLE M)
{
    ANALYZE_TABLE analyze_table;
    int ip = 0;
    input_string += "$";                                                //在输入符号串末尾加上结束符号$
    vector<string> stack;
    stack.push_back("$");                                              //stack用于存放推导过程中符号栈的变化，栈底以$填充
    stack.push_back(M.start_symbol);                                   //栈中填入文法起始符号作为开始标志
    while (stack.size() != 1)
    {
        vector<string> analyze_table_item;
        analyze_table.push_back(analyze_table_item);
        string stack_str = "[\"";
        for (auto iter = stack.begin(); iter != stack.end(); iter++)
        {
            stack_str += *iter + "\",\"";
        }
        stack_str.erase(stack_str.length() - 2, 2);
        stack_str += "]";
        analyze_table.back().push_back(stack_str);
        string input_str = input_string.substr(ip);
        analyze_table.back().push_back(input_str);                     //格式化符号栈analyze_table
        string X = stack.back();                                       //从符号栈stack的第一个符号(栈顶元素)开始比对
        //若栈顶元素等于终结符（find方法如果查找失败会返回end迭代器）
        if (find(M.terminator.begin(), M.terminator.end(), X) != M.terminator.end())
        {
            if (start_pattern(input_string.substr(ip), X))
            {
                ip += X.size();
                stack.pop_back();
            }
            //错误类型：输入符号与栈顶符号不匹配（终结符不匹配）
            else
            {
                error("Error:Input symbol does not match stack top symbol "+X+"!");
                return analyze_table;
            }
        }
        //若栈顶元素等于非终结符
        else if (find(M.nonterminal.begin(), M.nonterminal.end(), X) != M.nonterminal.end())
        {
            string input_string_first;
            if (input_string[ip] == 'i' && input_string[ip + 1] == 'd')
            {
                input_string_first = "id";
            }
            else
            {
                input_string_first = input_string.substr(ip, 1);
            }
            //错误类型：预测分析表中根本就没有相应的产生式或者对应的非终结符
            if (M.table.find(X) == M.table.end() || M.table.find(X)->second.find(input_string_first) == M.table.find(X)->second.end())
            {
                error("Error:There is no corresponding production of "+X+" in the Predict table!");
                return analyze_table;
            }
            string Y = M.table.find(X)->second.find(input_string_first)->second;
            //错误类型：预测分析表中对应的值为error
            if (Y == "error")
            {
                error("Error:The corresponding value of "+X+" in the Predict table is error!");
                return analyze_table;
            }
            else
            {
                stack.pop_back();
                if (Y != "ε")
                {
                    for (auto iter = Y.rbegin(); iter != Y.rend(); iter++)
                    {
                        string first;
                        if (*iter == 'd' && *(iter + 1) == 'i')
                        {
                            first = "id";
                            iter += 1;
                        }
                        else
                        {
                            first = string(1, *iter);
                        }
                        stack.push_back(first);
                    }
                    analyze_table.back().push_back(X + "->" + Y);
                }
                else
                {
                    analyze_table.back().push_back(X + "-><epsilon>");
                }
            }
        }
        //错误类型：栈顶元素既不是终结符也不是非终结符，属于非法符号
        else
        {
            error("Error:The top element of the stack "+X+" is an illegal symbol!");
            return analyze_table;
        }
    }
    if (input_string[ip] == '$')                                        //接受条件是最终输入符号串露出终结符号$(这里不需要再判断符号栈的栈底，因为只有符号栈size为1的时候才能退出while循环)
    {
        cout << "Accepted the Inpute string!" << endl;
        vector<string> analyze_table_item;
        analyze_table.push_back(analyze_table_item);
        analyze_table.back().push_back("[\"$\"]");                     //accepted之后还需要输出最后一行，也就是符号栈为["$"]，输入符号为$
        analyze_table.back().push_back("$");
    }
    //错误类型：不接受，此时符号栈已经为空但输入符号仍不为空
    else
    {
        error("Error:The stack is empty but the input string isn't!");
    }
    cout<<"Analyze table build successfully!"<<endl;
    return analyze_table;
}

void Syntax_Analyzer::print_analyze_table(ANALYZE_TABLE analyze_table)
{
    cout << "\t\t\t\t<====================Analyze table====================>" << endl;
    cout<<"Stack\t\t\t\t\t\tInput String\t\t\tProduction"<<endl;
    for (auto iter = analyze_table.begin(); iter != analyze_table.end(); iter++)
    {
        vector<string> analyze_table_item = *iter;
        for (auto iter2 = analyze_table_item.begin(); iter2 != analyze_table_item.end(); iter2++)
        {
            cout << *iter2;
            if (iter2 == analyze_table_item.begin())
            {
                for (int i = 0; i < 6 - iter2->size() / 8; i++)
                {
                    cout << "\t";
                }
            }
            else
            {
                for (int i = 0; i < 4 - iter2->size() / 8; i++)
                {
                    cout << "\t";
                }
            }
        }
        cout << endl;
    }
}

int Syntax_Analyzer::start_pattern(string str, string pattern)   //该函数的作用是在str字符串中寻找pattern子串，如果没找到返回0，找到则返回1
{
    return str.find(pattern) == 0 ? 1 : 0;
}

//输入字符串处理过程，注意这里只是语法分析不是语义分析，所以只需要将所有的数字转换为id即可
string Syntax_Analyzer::id_translate(string str)
{
    string newStr;
    int isid = 0;
    for (int i = 0; i < str.size(); i++)
    {
        if ((str[i] >= '0' && str[i] <= '9') || str[i] == '.')
        {
            if (!isid)
            {
                isid = 1;
                newStr += "id";
            }
            continue;
        }
        else
        {
            isid = 0;
            newStr += str[i];
        }
    }
    return newStr;
}





